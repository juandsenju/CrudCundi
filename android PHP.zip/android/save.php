<?php
	
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	require_once("db.php");

	$name = $_POST['name'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$phone = $_POST['phone'];

	$query = "INSERT INTO usuarios (nombre, email, password, telefono) VALUES ('$name', '$email', '$password', '$phone')";
	$result = $mysql->query($query);

	if($result === TRUE){
		echo "Usuario creado correctamente";
	} else{
		echo "Error en la creaci�n de usuario";
	}

	$mysql->close();
}


?>